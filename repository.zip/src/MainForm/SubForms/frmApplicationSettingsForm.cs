﻿/*
 * QBC- QuickBackupCreator
 * 
 * Copyright:   Oliver Kind - 2019
 * License:     LGPL
 * 
 * Desctiption:
 * A form to change the settings of the application
 * 
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the LGPL General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * LGPL General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not check the GitHub-Repository.
 * 
 * */

using OLKI.Programme.QBC.Properties;
using System;
using System.Windows.Forms;

namespace OLKI.Programme.QBC.MainForm.SubForms
{
    /// <summary>
    /// A form to change the settings of the application
    /// </summary>
    internal partial class ApplicationSettingsForm : Form
    {
        #region Properties
        /// <summary>
        /// True if clearing of the recent file list was requested
        /// </summary>
        private bool _clearRecentFiles = false;
        /// <summary>
        /// True if clearing of the recent file list was requested
        /// </summary>
        internal bool ClearRecentFiles
        {
            get
            {
                return this._clearRecentFiles;
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Initialise a new application SettingsForm
        /// </summary>
        internal ApplicationSettingsForm()
        {
            InitializeComponent();
            this.SetControlesFromSettings();
        }

        /// <summary>
        /// Set the properties of the controls from actual application settings
        /// </summary>
        private void SetControlesFromSettings()
        {
            this.txtDefaultPath.Text = Settings.Default.DefaultFilePath;
            this.txtDefaultFileOpen.Text = Settings.Default.DefaultFileOpen;
            this.chkAutoCheckFileAssociation.Checked = Settings.Default.AutoCheckFileAssociation;
            this.chkShowDirectorysWithoutAccess.Checked = Settings.Default.ShowDirectorysWithoutAccess;
            this.chkShowSystemDirectory.Checked = Settings.Default.ShowSystemDirectory;
            this.chkEypandTreeNodeOnClick.Checked = Settings.Default.ExpandTreeNodeOnClick;
            this.txtLogfileDateFormat.Text = Settings.Default.LogfileDateFormat;

            this.txtAddTextToFileDefaultText.Text = Settings.Default.Project_Settings_Common_ExisitingFile_TextToAdd_Default;
            this.txtAddTextToFileDateFormat.Text = Settings.Default.Project_Settings_Common_ExisitingFile_TextToAddDateFormat_Default;
        }

        #region Form events
        private void btnDefaultPath_Browse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog FolderBrowserDialog = new FolderBrowserDialog
            {
                Description = Stringtable._0x0006,
                SelectedPath = Settings.Default.DefaultFilePath
            };
            if (FolderBrowserDialog.ShowDialog(this) == DialogResult.OK)
            {
                this.txtDefaultPath.Text = FolderBrowserDialog.SelectedPath;
                Settings.Default.DefaultFilePath = FolderBrowserDialog.SelectedPath;
            }
        }

        private void btnDefaultPath_Delete_Click(object sender, EventArgs e)
        {
            this.txtDefaultPath.Text = string.Empty;
        }

        private void btnDefaultFileOpen_Browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog OpenFileDialog = new OpenFileDialog
            {
                DefaultExt = Settings.Default.FileFilterExtensionDefault,
                Filter = Settings.Default.ProjectFileFilterConfiguration,
                InitialDirectory = Settings.Default.DefaultFilePath,
                Multiselect = false
            };
            if (OpenFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                this.txtDefaultFileOpen.Text = OpenFileDialog.FileName;
            }
        }

        private void btnDefaultFileOpen_Delete_Click(object sender, EventArgs e)
        {
            this.txtDefaultFileOpen.Text = string.Empty;
        }

        private void btnRecentFilesClear_Click(object sender, EventArgs e)
        {
            this._clearRecentFiles = true;
        }

        private void btnCheckFileAssociation_Click(object sender, EventArgs e)
        {
            Program.CheckFileAssociationAndSet(true);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            Settings.Default.AutoCheckFileAssociation = this.chkAutoCheckFileAssociation.Checked;
            Settings.Default.DefaultFilePath = this.txtDefaultPath.Text;
            Settings.Default.DefaultFileOpen = this.txtDefaultFileOpen.Text;
            Settings.Default.ShowDirectorysWithoutAccess = this.chkShowDirectorysWithoutAccess.Checked;
            Settings.Default.ShowSystemDirectory = this.chkShowSystemDirectory.Checked;
            Settings.Default.ExpandTreeNodeOnClick = this.chkEypandTreeNodeOnClick.Checked;
            Settings.Default.LogfileDateFormat = this.txtLogfileDateFormat.Text;

            Settings.Default.Save();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void btnSetDefaults_Click(object sender, EventArgs e)
        {
            Settings.Default.Reset();
            this.SetControlesFromSettings();
        }
        #endregion
        #endregion
    }
}